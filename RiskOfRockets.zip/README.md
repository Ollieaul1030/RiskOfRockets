Just a slightly tweaked version of Rocket by EnforcerGang that makes it work with the new DLC 
I also fixed the host-client desync issue I discovered whilst playing with friends so we can all enjoy rocket jumping!

if you don't trust this version to not be a virus there is no obligation to use it, 
I simply decided to fix things myself so I could enjoy this awesome mod myself with my friends without having to wait for an update.